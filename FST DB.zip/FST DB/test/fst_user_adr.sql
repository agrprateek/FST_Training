-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.2.12-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping data for table test.fst_user_adr: ~3 rows (approximately)
/*!40000 ALTER TABLE `fst_user_adr` DISABLE KEYS */;
INSERT INTO `fst_user_adr` (`ROW_ID`, `FIRST_NAME`, `LAST_NAME`, `EMAIL_ID`, `PASSWORD`, `PHN_NO`, `APP_ID`, `USER_ID`) VALUES
	(1, 'Prateek', 'Agrawal', 'prateek185@gmail.com', 'welcome', NULL, 1, 'PA653D'),
	(2, 'Test', 'User', 'test@abc.com', 'welcome', NULL, 3, NULL),
	(3, 'UsFirstName', 'Ap', 'abc@gmail.com', 'welcome', 9663368216, 2, NULL);
/*!40000 ALTER TABLE `fst_user_adr` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
