package com.example.models;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FstAdrRecordRepository extends JpaRepository<FstAdrRecord,String>{

	//List<FstAdrRecord> findbyrowIdin(Iterator<FstAppAdr> iterator);

	//@Query("Select * from Fst_App_Adr T where t.appName='test'")
//	public FstUserAdr findOne(String rowId);
}
