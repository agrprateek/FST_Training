package com.example.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "fst_adr_record")

public class FstAdrRecord {
	
	@Column(name = "TITLE")
	String title;
	
	@Column(name = "STATUS")
	String status;
	
	@Column(name = "CONTEXT")
	String context;
	
	@Column(name = "OPTIONS")
	String options;
	
	@Column(name = "CONSTRAINTS")
	String constraints;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	String rowId;
	
	@Column(name = "DECISION")
	String decision;
	
	@Column(name = "IMPLICATIONS")
	String implications;
	
	@Column(name = "NOTES")
	String notes;
	

    
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getContext() {
		return context;
	}
	public void setContext(String context) {
		this.context = context;
	}
	public String getOptions() {
		return options;
	}
	public void setOptions(String options) {
		this.options = options;
	}
	public String getConstraints() {
		return constraints;
	}
	public void setConstraints(String constraints) {
		this.constraints = constraints;
	}
	public String getRowId() {
		return rowId;
	}
	public void setRowId(String rowId) {
		this.rowId = rowId;
	}
	public String getDecision() {
		return decision;
	}
	public void setDecision(String decision) {
		this.decision = decision;
	}
	public String getImplications() {
		return implications;
	}
	public void setImplications(String implications) {
		this.implications = implications;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}

	

}
