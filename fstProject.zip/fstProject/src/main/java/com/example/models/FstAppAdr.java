package com.example.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name= "fst_app_adr")

public class FstAppAdr {

	@Column(name = "APP_NAME")
	String appName;
	
	@Column(name = "USER_ID")
	String userid;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	String rowId;
	
	
	@OneToOne
    @JoinColumn(name = "APP_ADR_ID")
	public FstAdrRecord fstAdrRecord;
	

	    public FstAdrRecord getFstAdrRecord() {
	        return fstAdrRecord;
	    }

	    public void setFstAdrRecord(FstAdrRecord fstAdrRecord) {
	        this.fstAdrRecord = fstAdrRecord;
	    }
	    
	    
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getRowId() {
		return rowId;
	}
	public void setRowId(String rowId) {
		this.rowId = rowId;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}

	
}
