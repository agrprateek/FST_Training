package com.example.models;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FstAppAdrRepository extends JpaRepository<FstAppAdr,String>{

	//@Query("Select * from Fst_App_Adr T where t.appName='test'")
//	public FstUserAdr findOne(String rowId);
	
	List<FstAppAdr> findByuserid(String userid);
}
