package com.example.models;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface FstUserAdrRepository extends JpaRepository<FstUserAdr,String>{

	FstUserAdr findByattuid(String userid);

	//FstUserAdr findByattuidAndpassword(String userid,String password);

	//String existsByattuidAndpassword(String userid, String password);

	String existsByattuid(String userid);

	//@Query("Select * from Fst_App_Adr T where t.appName='test'")
//	public FstUserAdr findOne(String rowId);
	
}
