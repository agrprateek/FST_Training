package com.example.models;

public @interface ManytoOne {

}
