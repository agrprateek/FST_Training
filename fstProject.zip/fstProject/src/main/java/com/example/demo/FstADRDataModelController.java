package com.example.demo;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.example.models.FstAdrRecord;
import com.example.models.FstAdrRecordRepository;
import com.example.models.FstAppAdr;
import com.example.models.FstAppAdrRepository;
import com.example.models.FstUserAdr;
import com.example.models.FstUserAdrRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;


@Controller
@RestController
//@Produces({MediaType.APPLICATION_JSON})
public class FstADRDataModelController {
	
	@Autowired
	FstUserAdrRepository useradrreop;
	
	@Autowired
	FstAdrRecordRepository adrrecordrepo;
	
	@Autowired
	FstAppAdrRepository appadrrepo;
	
	
	@RequestMapping("/test")
	public FstUserAdr welcome() {
		System.out.println("test");
		FstUserAdr recins = useradrreop.findOne("2");
		return recins;
		
	}
	
	@RequestMapping("/test2/{userid}")
	public List<FstAppAdr> welcome2(@PathVariable(value="userid") String userid) {
		List<FstAppAdr> apprecs= appadrrepo.findByuserid(userid);
		//List<FstAdrRecord> apprecs= appadrrepo.findByuserid(userid);
		return apprecs;
	}
	@RequestMapping(value ="/test2/createadr", method = RequestMethod.GET)
	public String createAdrRec() {
		ObjectMapper mapper = new ObjectMapper();
		TypeReference<List<FstAdrRecord>> typeReference = new TypeReference<List<FstAdrRecord>>(){};
		InputStream inputStream = TypeReference.class.getResourceAsStream("/json/adrRecord.json");
		try {
			List<FstAdrRecord> adrRecords = mapper.readValue(inputStream,typeReference);
			adrrecordrepo.save(adrRecords);
			System.out.println("ADR record created");
		} catch (IOException e){
			System.out.println("Unable to save adr record: " + e.getMessage());
		}
		
		return "ADR Record Created";
	}
	@RequestMapping(value ="/test2/createapp", method = RequestMethod.GET)
	public String createAppRec() {
		ObjectMapper mapper = new ObjectMapper();
		TypeReference<List<FstAppAdr>> typeReference = new TypeReference<List<FstAppAdr>>(){};
		InputStream inputStream = TypeReference.class.getResourceAsStream("/json/appRecord.json");
		try {
			List<FstAppAdr> appRecords = mapper.readValue(inputStream,typeReference);
			appadrrepo.save(appRecords);
			System.out.println("App record created");
		} catch (IOException e){
			System.out.println("Unable to save app record: " + e.getMessage());
		}
		
		return "APP Record Created";
	}
	
	@RequestMapping(value ="/test2/uservalidation/{userid}/{password}", method = RequestMethod.GET)
	public boolean uservalidation(@PathVariable(value="userid") String userid,@PathVariable(value="password") String password) 
	{//,@PathVariable(value="password") String password
		FstUserAdr userrecins = new FstUserAdr();
		//String test = useradrreop.existsByattuid(userid);
		userrecins = useradrreop.findByattuid(userid);
		if(userrecins.getPassword() == password && !userrecins.getRowId().isEmpty())
		{
			return true;
		}
		else
			return false;
		//if(userrecins.getRowId()!=null)
		
		//return test;
	}
	
	@RequestMapping(value ="/test2/createuser", method = RequestMethod.GET)
	public String createUserRec() {
		
	//	FstUserAdr userrecins = new FstUserAdr();
		//String test = useradrreop.existsByattuid(userid);
	//	userrecins = useradrreop.findByattuid(userid);
		
		ObjectMapper mapper = new ObjectMapper();
		TypeReference<List<FstUserAdr>> typeReference = new TypeReference<List<FstUserAdr>>(){};
		InputStream inputStream = TypeReference.class.getResourceAsStream("/json/userRecord.json");
		try {
			List<FstUserAdr> userRecords = mapper.readValue(inputStream,typeReference);
			System.out.println(userRecords.get(0).getPhnNo());
			useradrreop.save(userRecords);
			System.out.println("User record created");
		} catch (IOException e){
			System.out.println("Unable to save User record: " + e.getMessage());
		}
		
		return "User Record Created";
	}
	
	@RequestMapping("/test/adrByUserId")
	public List<com.example.models.FstUserAdr> getAllAdr() {
		System.out.println("test");
		List<FstUserAdr> allFstUserAdr= useradrreop.findAll();	
		return allFstUserAdr;
	}

}
